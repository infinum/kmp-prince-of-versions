#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class POV__SkieSuspendWrappersKt, POVUpdateStatus, POVUShort, POVULong, POVUInt, POVUByte, POVSkie_SuspendResultSuccess, POVSkie_SuspendResultError, POVSkie_SuspendResultCanceled, POVSkie_SuspendResult, POVSkie_SuspendHandler, POVSkie_CancellationHandler, POVSkieKotlinStateFlow<T>, POVSkieKotlinSharedFlow<T>, POVSkieKotlinOptionalStateFlow<T>, POVSkieKotlinOptionalSharedFlow<T>, POVSkieKotlinOptionalMutableStateFlow<T>, POVSkieKotlinOptionalMutableSharedFlow<T>, POVSkieKotlinOptionalFlow<T>, POVSkieKotlinMutableStateFlow<T>, POVSkieKotlinMutableSharedFlow<T>, POVSkieKotlinFlow<T>, POVSkieColdFlowIterator<E>, POVShort, POVRequirementsNotSatisfiedException, POVPrinceOfVersionsComponentsBuilder, POVPrinceOfVersionsComponents, POVPrinceOfVersionsBaseCompanion, POVNumber, POVNotificationType, POVMutableSet<ObjectType>, POVMutableDictionary<KeyType, ObjectType>, POVLong, POVKotlinThrowable, POVKotlinRuntimeException, POVKotlinPair<A, B>, POVKotlinIllegalStateException, POVKotlinException, POVKotlinEnumCompanion, POVKotlinEnum<E>, POVKotlinCancellationException, POVKotlinArray<T>, POVIosStorageKt, POVIosPrinceOfVersionsKt, POVIosDefaultVersionComparatorKt, POVIoException, POVInt, POVFloat, POVDouble, POVConfigurationException, POVByte, POVBoolean, POVBaseUpdateResult<T>, POVBasePrinceOfVersionsConfig<T>, POVBase, NSString, NSSet<ObjectType>, NSObject, NSNumber, NSMutableSet<ObjectType>, NSMutableDictionary<KeyType, ObjectType>, NSMutableArray<ObjectType>, NSError, NSDictionary<KeyType, ObjectType>, NSArray<ObjectType>;

@protocol POVUpdateCallback, POVSkie_DispatcherDelegate, POVRequirementChecker, POVPrinceOfVersionsBase, POVLoader, POVKotlinx_coroutines_coreStateFlow, POVKotlinx_coroutines_coreSharedFlow, POVKotlinx_coroutines_coreRunnable, POVKotlinx_coroutines_coreMutableStateFlow, POVKotlinx_coroutines_coreMutableSharedFlow, POVKotlinx_coroutines_coreFlowCollector, POVKotlinx_coroutines_coreFlow, POVKotlinIterator, POVKotlinComparable, POVCancelable, POVBaseVersionComparator, POVBaseStorage, POVBasePrinceOfVersionsCall, POVBaseConfigurationParser, POVBaseApplicationVersionProvider, NSCopying;

// Due to an Obj-C/Swift interop limitation, SKIE cannot generate Swift types with a lambda type argument.
// Example of such type is: A<() -> Unit> where A<T> is a generic class.
// To avoid compilation errors SKIE replaces these type arguments with __SkieLambdaErrorType, resulting in A<__SkieLambdaErrorType>.
// Generated declarations that reference __SkieLambdaErrorType cannot be called in any way and the __SkieLambdaErrorType class cannot be used.
// The original declarations can still be used in the same way as other declarations hidden by SKIE (and with the same limitations as without SKIE).
@interface __SkieLambdaErrorType : NSObject
- (instancetype _Nonnull)init __attribute__((unavailable));
+ (instancetype _Nonnull)new __attribute__((unavailable));
@end

// Due to an Obj-C/Swift interop limitation, SKIE cannot generate Swift code that uses external Obj-C types for which SKIE doesn't know a fully qualified name.
// This problem occurs when custom Cinterop bindings are used because those do not contain the name of the Framework that provides implementation for those binding.
// The name can be configured manually using the SKIE Gradle configuration key 'ClassInterop.CInteropFrameworkName' in the same way as other SKIE features.
// To avoid compilation errors SKIE replaces types with unknown Framework name with __SkieUnknownCInteropFrameworkErrorType.
// Generated declarations that reference __SkieUnknownCInteropFrameworkErrorType cannot be called in any way and the __SkieUnknownCInteropFrameworkErrorType class cannot be used.
@interface __SkieUnknownCInteropFrameworkErrorType : NSObject
- (instancetype _Nonnull)init __attribute__((unavailable));
+ (instancetype _Nonnull)new __attribute__((unavailable));
@end


NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface POVBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface POVBase (POVBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface POVMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface POVMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorPOVKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface POVNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface POVByte : POVNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface POVUByte : POVNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface POVShort : POVNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface POVUShort : POVNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface POVInt : POVNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface POVUInt : POVNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface POVLong : POVNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface POVULong : POVNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface POVFloat : POVNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface POVDouble : POVNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface POVBoolean : POVNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieColdFlowIterator")))
@interface POVSkieColdFlowIterator<E> : POVBase
- (instancetype)initWithFlow:(id<POVKotlinx_coroutines_coreFlow>)flow __attribute__((swift_name("init(flow:)"))) __attribute__((objc_designated_initializer));
- (void)cancel __attribute__((swift_name("cancel()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)hasNextWithCompletionHandler:(void (^)(POVBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("hasNext(completionHandler:)")));
- (E _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol POVKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinFlow")))
@interface POVSkieKotlinFlow<__covariant T> : POVBase <POVKotlinx_coroutines_coreFlow>
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSharedFlow")))
@protocol POVKotlinx_coroutines_coreSharedFlow <POVKotlinx_coroutines_coreFlow>
@required
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol POVKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreMutableSharedFlow")))
@protocol POVKotlinx_coroutines_coreMutableSharedFlow <POVKotlinx_coroutines_coreSharedFlow, POVKotlinx_coroutines_coreFlowCollector>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(id _Nullable)value __attribute__((swift_name("tryEmit(value:)")));
@property (readonly) id<POVKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinMutableSharedFlow")))
@interface POVSkieKotlinMutableSharedFlow<T> : POVBase <POVKotlinx_coroutines_coreMutableSharedFlow>
@property (readonly) NSArray<T> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) id<POVKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreMutableSharedFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(T)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(T)value __attribute__((swift_name("tryEmit(value:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreStateFlow")))
@protocol POVKotlinx_coroutines_coreStateFlow <POVKotlinx_coroutines_coreSharedFlow>
@required
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreMutableStateFlow")))
@protocol POVKotlinx_coroutines_coreMutableStateFlow <POVKotlinx_coroutines_coreStateFlow, POVKotlinx_coroutines_coreMutableSharedFlow>
@required
- (void)setValue:(id _Nullable)value __attribute__((swift_name("setValue(_:)")));
- (BOOL)compareAndSetExpect:(id _Nullable)expect update:(id _Nullable)update __attribute__((swift_name("compareAndSet(expect:update:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinMutableStateFlow")))
@interface POVSkieKotlinMutableStateFlow<T> : POVBase <POVKotlinx_coroutines_coreMutableStateFlow>
@property (readonly) NSArray<T> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) id<POVKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
@property T value __attribute__((swift_name("value")));
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreMutableStateFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
- (BOOL)compareAndSetExpect:(T)expect update:(T)update __attribute__((swift_name("compareAndSet(expect:update:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(T)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(T)value __attribute__((swift_name("tryEmit(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalFlow")))
@interface POVSkieKotlinOptionalFlow<__covariant T> : POVBase <POVKotlinx_coroutines_coreFlow>
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalMutableSharedFlow")))
@interface POVSkieKotlinOptionalMutableSharedFlow<T> : POVBase <POVKotlinx_coroutines_coreMutableSharedFlow>
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) id<POVKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreMutableSharedFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(T _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(T _Nullable)value __attribute__((swift_name("tryEmit(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalMutableStateFlow")))
@interface POVSkieKotlinOptionalMutableStateFlow<T> : POVBase <POVKotlinx_coroutines_coreMutableStateFlow>
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) id<POVKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
@property T _Nullable value __attribute__((swift_name("value")));
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreMutableStateFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
- (BOOL)compareAndSetExpect:(T _Nullable)expect update:(T _Nullable)update __attribute__((swift_name("compareAndSet(expect:update:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(T _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(T _Nullable)value __attribute__((swift_name("tryEmit(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalSharedFlow")))
@interface POVSkieKotlinOptionalSharedFlow<__covariant T> : POVBase <POVKotlinx_coroutines_coreSharedFlow>
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreSharedFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinOptionalStateFlow")))
@interface POVSkieKotlinOptionalStateFlow<__covariant T> : POVBase <POVKotlinx_coroutines_coreStateFlow>
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreStateFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinSharedFlow")))
@interface POVSkieKotlinSharedFlow<__covariant T> : POVBase <POVKotlinx_coroutines_coreSharedFlow>
@property (readonly) NSArray<T> *replayCache __attribute__((swift_name("replayCache")));
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreSharedFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkieKotlinStateFlow")))
@interface POVSkieKotlinStateFlow<__covariant T> : POVBase <POVKotlinx_coroutines_coreStateFlow>
@property (readonly) NSArray<T> *replayCache __attribute__((swift_name("replayCache")));
@property (readonly) T value __attribute__((swift_name("value")));
- (instancetype)initWithDelegate:(id<POVKotlinx_coroutines_coreStateFlow>)delegate __attribute__((swift_name("init(_:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_CancellationHandler")))
@interface POVSkie_CancellationHandler : POVBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)cancel __attribute__((swift_name("cancel()")));
@end

__attribute__((swift_name("Skie_DispatcherDelegate")))
@protocol POVSkie_DispatcherDelegate
@required
- (void)dispatchBlock:(id<POVKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(block:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_SuspendHandler")))
@interface POVSkie_SuspendHandler : POVBase
- (instancetype)initWithCancellationHandler:(POVSkie_CancellationHandler *)cancellationHandler dispatcherDelegate:(id<POVSkie_DispatcherDelegate>)dispatcherDelegate onResult:(void (^)(POVSkie_SuspendResult *))onResult __attribute__((swift_name("init(cancellationHandler:dispatcherDelegate:onResult:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Skie_SuspendResult")))
@interface POVSkie_SuspendResult : POVBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_SuspendResult.Canceled")))
@interface POVSkie_SuspendResultCanceled : POVSkie_SuspendResult
@property (class, readonly, getter=shared) POVSkie_SuspendResultCanceled *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)canceled __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_SuspendResult.Error")))
@interface POVSkie_SuspendResultError : POVSkie_SuspendResult
@property (readonly) NSError *error __attribute__((swift_name("error")));
- (instancetype)initWithError:(NSError *)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (POVSkie_SuspendResultError *)doCopyError:(NSError *)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Skie_SuspendResult.Success")))
@interface POVSkie_SuspendResultSuccess : POVSkie_SuspendResult
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
- (instancetype)initWithValue:(id _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (POVSkie_SuspendResultSuccess *)doCopyValue:(id _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * Provides the current version of the application.
 */
__attribute__((swift_name("BaseApplicationVersionProvider")))
@protocol POVBaseApplicationVersionProvider
@required
- (id _Nullable)getVersion __attribute__((swift_name("getVersion()")));
@end


/**
 * This class parses update resource text into [BasePrinceOfVersionsConfig].
 */
__attribute__((swift_name("BaseConfigurationParser")))
@protocol POVBaseConfigurationParser
@required

/**
 * Parses update resource into [BasePrinceOfVersionsConfig].
 *
 * @param value text representation of update resource.
 * @return Class which holds all relevant data.
 * @throws Throwable if error happens during parsing.
 *
 * @note This method converts all Kotlin exceptions to errors.
*/
- (POVBasePrinceOfVersionsConfig<id> * _Nullable)parseValue:(NSString *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("parse(value:)")));
@end


/**
 * Represents a single, prepared call to check for an update.
 *
 * An instance of this class is a one-shot object; it can be used only once.
 * To perform another check, a new instance must be created
 * via [PrinceOfVersionsBase.newCall].
 *
 * This interface provides two ways to perform the update check:
 * - [enqueue] for an asynchronous, callback-based approach.
 * - [execute] for a synchronous-style, coroutine-based approach.
 */
__attribute__((swift_name("BasePrinceOfVersionsCall")))
@protocol POVBasePrinceOfVersionsCall
@required

/**
 * Schedules the update check to be executed asynchronously.
 *
 * The check will be performed on a background thread, and the result will be
 * delivered to the provided [callback] on the main thread.
 *
 * @param callback The callback to notify with the update result or an error.
 * @return A [Cancelable] handle that can be used to cancel the ongoing check.
 *
 */
- (id<POVCancelable>)enqueueCallback:(id<POVUpdateCallback>)callback __attribute__((swift_name("enqueue(callback:)")));

/**
 * Executes the update check.
 *
 * @return The [BaseUpdateResult] of the check.
 *
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeWithCompletionHandler:(void (^)(POVBaseUpdateResult<id> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(completionHandler:)")));
@end


/**
 * This class holds loaded data from a configuration resource.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasePrinceOfVersionsConfig")))
@interface POVBasePrinceOfVersionsConfig<T> : POVBase
@property (readonly) T _Nullable mandatoryVersion __attribute__((swift_name("mandatoryVersion")));
@property (readonly) NSDictionary<NSString *, id> *metadata __attribute__((swift_name("metadata")));
@property (readonly) POVNotificationType *optionalNotificationType __attribute__((swift_name("optionalNotificationType")));
@property (readonly) T _Nullable optionalVersion __attribute__((swift_name("optionalVersion")));
@property (readonly) NSDictionary<NSString *, id> *requirements __attribute__((swift_name("requirements")));
- (instancetype)initWithMandatoryVersion:(T _Nullable)mandatoryVersion optionalVersion:(T _Nullable)optionalVersion optionalNotificationType:(POVNotificationType *)optionalNotificationType metadata:(NSDictionary<NSString *, id> *)metadata requirements:(NSDictionary<NSString *, id> *)requirements __attribute__((swift_name("init(mandatoryVersion:optionalVersion:optionalNotificationType:metadata:requirements:)"))) __attribute__((objc_designated_initializer));
- (POVBasePrinceOfVersionsConfig<T> *)doCopyMandatoryVersion:(T _Nullable)mandatoryVersion optionalVersion:(T _Nullable)optionalVersion optionalNotificationType:(POVNotificationType *)optionalNotificationType metadata:(NSDictionary<NSString *, id> *)metadata requirements:(NSDictionary<NSString *, id> *)requirements __attribute__((swift_name("doCopy(mandatoryVersion:optionalVersion:optionalNotificationType:metadata:requirements:)")));

/**
 * This class holds loaded data from a configuration resource.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * This class holds loaded data from a configuration resource.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * This class holds loaded data from a configuration resource.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * Represents a local device storage object that can be used to save and retrieve the application version.
 */
__attribute__((swift_name("BaseStorage")))
@protocol POVBaseStorage
@required

/**
 * Returns the last saved version of the application.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getLastSavedVersionWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getLastSavedVersion(completionHandler:)")));

/**
 * Saves the version to the devices local storage
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)saveVersionVersion:(id _Nullable)version completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("saveVersion(version:completionHandler:)")));
@end


/**
 * Represents the final result of an update check.
 *
 * This data class encapsulates all the information needed to act on the
 * result of a Prince of Versions check, such as showing a dialog to the user.
 *
 * @param T the type of a version that is being checked.
 * @property version The version of the available update. In the case of [UpdateStatus.NO_UPDATE], this will
 * be the currently installed version of the application.
 * @property status The final status of the update check, indicating whether an update is available, mandatory,
 * or if there is no update.
 * @property metadata A map of metadata associated with the resolved update configuration. This is provided even
 * if no update is available.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseUpdateResult")))
@interface POVBaseUpdateResult<T> : POVBase
@property (readonly) NSDictionary<NSString *, id> *metadata __attribute__((swift_name("metadata")));
@property (readonly) POVUpdateStatus *status __attribute__((swift_name("status")));
@property (readonly) T _Nullable version __attribute__((swift_name("version")));
- (instancetype)initWithVersion:(T _Nullable)version status:(POVUpdateStatus *)status metadata:(NSDictionary<NSString *, id> *)metadata __attribute__((swift_name("init(version:status:metadata:)"))) __attribute__((objc_designated_initializer));
- (POVBaseUpdateResult<T> *)doCopyVersion:(T _Nullable)version status:(POVUpdateStatus *)status metadata:(NSDictionary<NSString *, id> *)metadata __attribute__((swift_name("doCopy(version:status:metadata:)")));

/**
 * Represents the final result of an update check.
 *
 * This data class encapsulates all the information needed to act on the
 * result of a Prince of Versions check, such as showing a dialog to the user.
 *
 * @param T the type of a version that is being checked.
 * @property version The version of the available update. In the case of [UpdateStatus.NO_UPDATE], this will
 * be the currently installed version of the application.
 * @property status The final status of the update check, indicating whether an update is available, mandatory,
 * or if there is no update.
 * @property metadata A map of metadata associated with the resolved update configuration. This is provided even
 * if no update is available.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Represents the final result of an update check.
 *
 * This data class encapsulates all the information needed to act on the
 * result of a Prince of Versions check, such as showing a dialog to the user.
 *
 * @param T the type of a version that is being checked.
 * @property version The version of the available update. In the case of [UpdateStatus.NO_UPDATE], this will
 * be the currently installed version of the application.
 * @property status The final status of the update check, indicating whether an update is available, mandatory,
 * or if there is no update.
 * @property metadata A map of metadata associated with the resolved update configuration. This is provided even
 * if no update is available.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Represents the final result of an update check.
 *
 * This data class encapsulates all the information needed to act on the
 * result of a Prince of Versions check, such as showing a dialog to the user.
 *
 * @param T the type of a version that is being checked.
 * @property version The version of the available update. In the case of [UpdateStatus.NO_UPDATE], this will
 * be the currently installed version of the application.
 * @property status The final status of the update check, indicating whether an update is available, mandatory,
 * or if there is no update.
 * @property metadata A map of metadata associated with the resolved update configuration. This is provided even
 * if no update is available.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("BaseVersionComparator")))
@protocol POVBaseVersionComparator
@required

/**
 * Compares two versions and returns an integer value.
 *
 * @param firstVersion the first version to compare
 * @param secondVersion the second version to compare
 *
 * @return Zero if the values is equal, a positive number if firstVersion is greater than secondVersion,
 * or a negative number if firstVersion is less than secondVersion.
 */
- (int32_t)compareFirstVersion:(id _Nullable)firstVersion secondVersion:(id _Nullable)secondVersion __attribute__((swift_name("compare(firstVersion:secondVersion:)")));
@end


/**
 * Represents a handle to an ongoing asynchronous operation that can be canceled.
 *
 * This provides a common mechanism to signal cancellation to a task that may be
 * running in the background.
 */
__attribute__((swift_name("Cancelable")))
@protocol POVCancelable
@required

/**
 * Attempts to cancel the ongoing operation.
 *
 * Calling this method signals that the operation should be aborted.
 * It is a best-effort cancellation and may not have an effect if the
 * operation has already completed or is in a non-cancellable state.
 */
- (void)cancel __attribute__((swift_name("cancel()")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface POVKotlinThrowable : POVBase
@property (readonly) POVKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (POVKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface POVKotlinException : POVKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfigurationException")))
@interface POVConfigurationException : POVKotlinException
- (instancetype)initWithMessage:(NSString *)message cause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IoException")))
@interface POVIoException : POVKotlinException
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end


/**
 * Represents a source from which the update configuration can be loaded.
 */
__attribute__((swift_name("Loader")))
@protocol POVLoader
@required

/**
 * Loads the configuration content and returns it as a string.
 *
 * @return The configuration content as a [String].
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loadWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("load(completionHandler:)")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol POVKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface POVKotlinEnum<E> : POVBase <POVKotlinComparable>
@property (class, readonly, getter=companion) POVKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * Type of notification used to determine if already notified updates should be notified again for optional version.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NotificationType")))
@interface POVNotificationType : POVKotlinEnum<POVNotificationType *>
@property (class, readonly) POVNotificationType *once __attribute__((swift_name("once")));
@property (class, readonly) POVNotificationType *always __attribute__((swift_name("always")));
@property (class, readonly) NSArray<POVNotificationType *> *entries __attribute__((swift_name("entries")));
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Type of notification used to determine if already notified updates should be notified again for optional version.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (POVKotlinArray<POVNotificationType *> *)values __attribute__((swift_name("values()")));
@end


/**
 * Represents the base generic interface for using the library.
 *
 * This library checks for application updates by fetching a configuration from a given source.
 *
 */
__attribute__((swift_name("PrinceOfVersionsBase")))
@protocol POVPrinceOfVersionsBase
@required

/**
 * Starts a check for an update.
 *
 * @param source The source from which to load the update configuration.
 *
 * @return An [BaseUpdateResult] instance that contains the result of the update check.
 *
 * @note This method converts instances of Exception to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)checkForUpdatesSource:(id<POVLoader>)source completionHandler:(void (^)(POVBaseUpdateResult<id> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("checkForUpdates(source:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinceOfVersionsBaseCompanion")))
@interface POVPrinceOfVersionsBaseCompanion : POVBase
@property (class, readonly, getter=shared) POVPrinceOfVersionsBaseCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) int64_t DEFAULT_NETWORK_TIMEOUT __attribute__((swift_name("DEFAULT_NETWORK_TIMEOUT")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinceOfVersionsComponents")))
@interface POVPrinceOfVersionsComponents : POVBase
@property (readonly) id<POVBaseConfigurationParser> configurationParser __attribute__((swift_name("configurationParser")));
@property (readonly) NSDictionary<NSString *, id<POVRequirementChecker>> *requirementCheckers __attribute__((swift_name("requirementCheckers")));
@property (readonly) id<POVBaseStorage> storage __attribute__((swift_name("storage")));
@property (readonly) id<POVBaseVersionComparator> versionComparator __attribute__((swift_name("versionComparator")));
@property (readonly) id<POVBaseApplicationVersionProvider> versionProvider __attribute__((swift_name("versionProvider")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinceOfVersionsComponents.Builder")))
@interface POVPrinceOfVersionsComponentsBuilder : POVBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (POVPrinceOfVersionsComponents *)build __attribute__((swift_name("build()")));
- (POVPrinceOfVersionsComponentsBuilder *)withConfigurationParserParser:(id<POVBaseConfigurationParser>)parser __attribute__((swift_name("withConfigurationParser(parser:)")));

/**
 * @param checkers A map of requirement checkers, where each key is a string identifier for a requirement.
 * @param keepDefaultCheckers If true, merges with defaults (OS version). If false, replaces them.
 */
- (POVPrinceOfVersionsComponentsBuilder *)withRequirementCheckersCheckers:(NSDictionary<NSString *, id<POVRequirementChecker>> *)checkers keepDefaultCheckers:(BOOL)keepDefaultCheckers __attribute__((swift_name("withRequirementCheckers(checkers:keepDefaultCheckers:)")));
- (POVPrinceOfVersionsComponentsBuilder *)withStorageStorage:(id<POVBaseStorage>)storage __attribute__((swift_name("withStorage(storage:)")));
- (POVPrinceOfVersionsComponentsBuilder *)withVersionComparatorComparator:(id<POVBaseVersionComparator>)comparator __attribute__((swift_name("withVersionComparator(comparator:)")));
- (POVPrinceOfVersionsComponentsBuilder *)withVersionProviderProvider:(id<POVBaseApplicationVersionProvider>)provider __attribute__((swift_name("withVersionProvider(provider:)")));
@end

__attribute__((swift_name("RequirementChecker")))
@protocol POVRequirementChecker
@required
- (BOOL)checkRequirementsValue:(NSString * _Nullable)value __attribute__((swift_name("checkRequirements(value:)")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface POVKotlinRuntimeException : POVKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface POVKotlinIllegalStateException : POVKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * An exception thrown when there is no available update that satisfies the specified requirements.
 *
 * @param sourceMetadata The default metadata from the root object in the configuration file.
 * A defensive copy is made to ensure immutability.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RequirementsNotSatisfiedException")))
@interface POVRequirementsNotSatisfiedException : POVKotlinIllegalStateException
@property (readonly) NSDictionary<NSString *, id> *metadata __attribute__((swift_name("metadata")));
- (instancetype)initWithSourceMetadata:(NSDictionary<NSString *, id> *)sourceMetadata __attribute__((swift_name("init(sourceMetadata:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * A copy of the metadata from the update configuration.
 */
@end


/**
 * A callback interface used to deliver the result of an update check.
 *
 * Implement this interface to handle the success, failure, or no-update scenarios
 * of a Prince of Versions check.
 */
__attribute__((swift_name("UpdateCallback")))
@protocol POVUpdateCallback
@required

/**
 * Called when an error occurs during the update check.
 *
 * @param error The [Throwable] that occurred.
 */
- (void)onErrorError:(POVKotlinThrowable *)error __attribute__((swift_name("onError(error:)")));

/**
 * Called when a new update is available.
 *
 * @param version The version string of the new update.
 * @param isMandatory True if the update is mandatory, false otherwise.
 * @param metadata A map of metadata associated with the update.
 */
- (void)onNewUpdateVersion:(NSString *)version isMandatory:(BOOL)isMandatory metadata:(NSDictionary<NSString *, NSString *> *)metadata __attribute__((swift_name("onNewUpdate(version:isMandatory:metadata:)")));

/**
 * Called when no new update is available for the user.
 *
 * @param metadata A map of metadata from the configuration, which may still be useful
 * even if there is no update.
 */
- (void)onNoUpdateMetadata:(NSDictionary<NSString *, NSString *> *)metadata __attribute__((swift_name("onNoUpdate(metadata:)")));
@end


/**
 * Represents the final status of an update check.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateStatus")))
@interface POVUpdateStatus : POVKotlinEnum<POVUpdateStatus *>
@property (class, readonly) POVUpdateStatus *noUpdate __attribute__((swift_name("noUpdate")));
@property (class, readonly) POVUpdateStatus *optional __attribute__((swift_name("optional")));
@property (class, readonly) POVUpdateStatus *mandatory __attribute__((swift_name("mandatory")));
@property (class, readonly) NSArray<POVUpdateStatus *> *entries __attribute__((swift_name("entries")));
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Represents the final status of an update check.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (POVKotlinArray<POVUpdateStatus *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IosDefaultVersionComparatorKt")))
@interface POVIosDefaultVersionComparatorKt : POVBase
+ (id<POVBaseVersionComparator>)defaultIosVersionComparator __attribute__((swift_name("defaultIosVersionComparator()")));
+ (id<POVPrinceOfVersionsBase>)princeOfVersionsWithCustomParserParser:(id<POVBaseConfigurationParser>)parser __attribute__((swift_name("princeOfVersionsWithCustomParser(parser:)")));
+ (id<POVPrinceOfVersionsBase>)princeOfVersionsWithCustomVersionLogicProvider:(id<POVBaseApplicationVersionProvider>)provider comparator:(id<POVBaseVersionComparator>)comparator __attribute__((swift_name("princeOfVersionsWithCustomVersionLogic(provider:comparator:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IosPrinceOfVersionsKt")))
@interface POVIosPrinceOfVersionsKt : POVBase

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)checkForUpdates:(id<POVPrinceOfVersionsBase>)receiver url:(NSString *)url username:(NSString * _Nullable)username password:(NSString * _Nullable)password networkTimeout:(int64_t)networkTimeout completionHandler:(void (^)(POVBaseUpdateResult<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("checkForUpdates(_:url:username:password:networkTimeout:completionHandler:)")));

/**
 * Starts a check for an update, loading the configuration from a URL (iOS actual).
 *
 * @note This method converts instances of IoException, RequirementsNotSatisfiedException, ConfigurationException, CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)checkForUpdatesFromUrl:(id<POVPrinceOfVersionsBase>)receiver url:(NSString *)url username:(NSString * _Nullable)username password:(NSString * _Nullable)password networkTimeout:(int64_t)networkTimeout completionHandler:(void (^)(POVBaseUpdateResult<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("checkForUpdatesFromUrl(_:url:username:password:networkTimeout:completionHandler:)")));
+ (id<POVPrinceOfVersionsBase>)createPrinceOfVersions __attribute__((swift_name("createPrinceOfVersions()")));

/**
 * Convenience for Swift: build PoV with a single custom checker.
 */
+ (id<POVPrinceOfVersionsBase>)princeOfVersionsWithCustomCheckerKey:(NSString *)key checker:(id<POVRequirementChecker>)checker keepDefaultCheckers:(BOOL)keepDefaultCheckers __attribute__((swift_name("princeOfVersionsWithCustomChecker(key:checker:keepDefaultCheckers:)")));

/**
 * Convenience for Swift: build PoV with many custom checkers.
 * In Swift you can pass an array of KotlinPair<String, RequirementChecker>.
 */
+ (id<POVPrinceOfVersionsBase>)princeOfVersionsWithCustomCheckersPairs:(POVKotlinArray<POVKotlinPair<NSString *, id<POVRequirementChecker>> *> *)pairs keepDefaultCheckers:(BOOL)keepDefaultCheckers __attribute__((swift_name("princeOfVersionsWithCustomCheckers(pairs:keepDefaultCheckers:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IosStorageKt")))
@interface POVIosStorageKt : POVBase
+ (id<POVPrinceOfVersionsBase>)princeOfVersionsWithCustomStorageStorage:(id<POVBaseStorage>)storage __attribute__((swift_name("princeOfVersionsWithCustomStorage(storage:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("__SkieSuspendWrappersKt")))
@interface POV__SkieSuspendWrappersKt : POVBase
+ (void)Skie_Suspend__0__checkForUpdatesExtensionReceiver:(id<POVPrinceOfVersionsBase>)extensionReceiver url:(NSString *)url username:(NSString * _Nullable)username password:(NSString * _Nullable)password networkTimeout:(int64_t)networkTimeout suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__0__checkForUpdates(extensionReceiver:url:username:password:networkTimeout:suspendHandler:)")));
+ (void)Skie_Suspend__1__checkForUpdatesFromUrlExtensionReceiver:(id<POVPrinceOfVersionsBase>)extensionReceiver url:(NSString *)url username:(NSString * _Nullable)username password:(NSString * _Nullable)password networkTimeout:(int64_t)networkTimeout suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__1__checkForUpdatesFromUrl(extensionReceiver:url:username:password:networkTimeout:suspendHandler:)")));
+ (void)Skie_Suspend__2__hasNextDispatchReceiver:(POVSkieColdFlowIterator<id> *)dispatchReceiver suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__2__hasNext(dispatchReceiver:suspendHandler:)")));
+ (void)Skie_Suspend__3__collectDispatchReceiver:(id<POVKotlinx_coroutines_coreFlow>)dispatchReceiver collector:(id<POVKotlinx_coroutines_coreFlowCollector>)collector suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__3__collect(dispatchReceiver:collector:suspendHandler:)")));
+ (void)Skie_Suspend__4__emitDispatchReceiver:(id<POVKotlinx_coroutines_coreFlowCollector>)dispatchReceiver value:(id _Nullable)value suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__4__emit(dispatchReceiver:value:suspendHandler:)")));
+ (void)Skie_Suspend__5__executeDispatchReceiver:(id<POVBasePrinceOfVersionsCall>)dispatchReceiver suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__5__execute(dispatchReceiver:suspendHandler:)")));
+ (void)Skie_Suspend__6__getLastSavedVersionDispatchReceiver:(id<POVBaseStorage>)dispatchReceiver suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__6__getLastSavedVersion(dispatchReceiver:suspendHandler:)")));
+ (void)Skie_Suspend__7__saveVersionDispatchReceiver:(id<POVBaseStorage>)dispatchReceiver version:(id _Nullable)version suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__7__saveVersion(dispatchReceiver:version:suspendHandler:)")));
+ (void)Skie_Suspend__8__loadDispatchReceiver:(id<POVLoader>)dispatchReceiver suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__8__load(dispatchReceiver:suspendHandler:)")));
+ (void)Skie_Suspend__9__checkForUpdatesDispatchReceiver:(id<POVPrinceOfVersionsBase>)dispatchReceiver source:(id<POVLoader>)source suspendHandler:(POVSkie_SuspendHandler *)suspendHandler __attribute__((swift_name("Skie_Suspend__9__checkForUpdates(dispatchReceiver:source:suspendHandler:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface POVKotlinCancellationException : POVKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(POVKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol POVKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface POVKotlinArray<T> : POVBase
@property (readonly) int32_t size __attribute__((swift_name("size")));
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(POVInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<POVKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface POVKotlinEnumCompanion : POVBase
@property (class, readonly, getter=shared) POVKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinPair")))
@interface POVKotlinPair<__covariant A, __covariant B> : POVBase
@property (readonly) A _Nullable first __attribute__((swift_name("first")));
@property (readonly) B _Nullable second __attribute__((swift_name("second")));
- (instancetype)initWithFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("init(first:second:)"))) __attribute__((objc_designated_initializer));
- (POVKotlinPair<A, B> *)doCopyFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("doCopy(first:second:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol POVKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
